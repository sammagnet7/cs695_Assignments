#include <stdio.h>

int main()
{
    int i =5;
    int k;
    {
        while(i==5)
        {
            k =1;
        }
    }
    return 0;
}