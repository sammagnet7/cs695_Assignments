test.c => is written to imitate the test cases.
makefile => additional funtions like clear, load, unload is added

**spock.sh => RUN THIS SCRIPT IN SUDO which in turn will runn all the functions cleanly along with the test case.