makefile => additional funtions like clear, load, unload is added

**run_dr_doom.sh => RUN THIS SCRIPT IN SUDO which in turn will runn all the functions cleanly along with the test case.